

import java.io.Serializable; 

/**
 * serializable message that can be send over the sockets between client and
 * server. 
 */
public   class  TextMessage  implements Serializable {
	

	private static final long serialVersionUID = -9161595018411902079L;

	
	
	protected String content;

	

	public TextMessage(String content) {
		setContent(content);
	}

	
	
	 private void  setContent__wrappee__Chat  (String content) {
		this.content = content;
	}

	

	 private void  setContent__wrappee__BackwardsEncryption  (String content) {
		setContent__wrappee__Chat(backwards(content));
	}

	
	
	public void setContent(String content) {
		setContent__wrappee__BackwardsEncryption(rotate(content, KEY));
	}

	

	 private String  getContent__wrappee__Chat  () {
		return content;
	}

	

	 private String  getContent__wrappee__BackwardsEncryption  () {
		return backwards(getContent__wrappee__Chat());
	}

	

	public String getContent() {
		return rotate(getContent__wrappee__BackwardsEncryption(), -KEY);
	}

	

	private String backwards(String text) {
		char[] chars = new char[text.length()];
		for (int i = 0; i < text.length(); i++)
			chars[i] = text.charAt(text.length() - i - 1);
		return new String(chars);
	}

	

	private static final int KEY = 13;

	

	private String rotate(String text, int key) {
		char[] chars = text.toCharArray();
		for (int i = 0; i < chars.length; i++)
			chars[i] = (char) (chars[i] + key);
		return new String(chars);
	}


}
