

import java.io.BufferedWriter; 
import java.io.FileWriter; 

public   class  Log {
	
	
	 private void  write__wrappee__Chat  (String line) {
	}

	
	
	public void write(String line) {
		write__wrappee__Chat(line);
		try {
			writer.append(line);
			writer.newLine();
			writer.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	
	private final String LOG_FILE = "log" + System.currentTimeMillis() + ".txt";

	
	
	private BufferedWriter writer;

	
	
	public Log() {
		try {
			writer = new BufferedWriter(new FileWriter(LOG_FILE));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


}
