

public   class  Starter {
	
	
	 private static void  main__wrappee__Base  (String args[]) 
	{

		System.out.print("starting ");

	}

	
	
	 private static void  main__wrappee__Server  (String args[]) 
	{
		main__wrappee__Base(args);
		System.out.println("server... ");
		
		new ServerGui();

	}

	
	public static void main(String args[]) 
	{
		main__wrappee__Server(args);
		System.out.println("client... ");
		
		new StartingGui();

	}


}
