

import java.io.IOException; 
import java.io.ObjectInputStream; 
import java.io.ObjectOutputStream; 
import java.net.Socket; 
import java.util.LinkedList; 
import java.util.List; 

public   class  Client  implements Runnable {
	

	public static void main(String args[]) throws IOException {
		if (args.length != 2)
			throw new RuntimeException("Syntax: ChatClient <host> <port>");
		new Client(args[0], Integer.parseInt(args[1]));
	}

	
	
	protected ObjectInputStream inputStream;

	
	protected ObjectOutputStream outputStream;

	
	protected Thread thread;

	
	
	public Client(String host, int port) {
		try {
			System.out.println("Connecting to " + host + " (port " + port + ")...");
			Socket s = new Socket(host, port);
			this.outputStream = new ObjectOutputStream((s.getOutputStream()));
			this.inputStream = new ObjectInputStream((s.getInputStream()));
			thread = new Thread(this);
			thread.start();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	

	/**
	 * main method. waits for incoming messages.
	 */
	 private void  run__wrappee__Base  () {
		try {
			while (true) {
				try {
					Object msg = inputStream.readObject();
					handleIncomingMessage(msg);
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			thread = null;
			try {
				outputStream.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}

	
	
	 private void  run__wrappee__GUI  () {
		gui = new Gui(this);
		run__wrappee__Base();	
	}

	

	 private void  run__wrappee__History  () {
		history = new History("Client.txt");
		run__wrappee__GUI();
	}

	

	public void run() {
		send(password);
		run__wrappee__History();	
	}

	

	/**
	 * decides what to do with incoming messages
	 * 
	 * @param msg
	 *            the message (Object) received from the sockets
	 */
	protected void handleIncomingMessage(Object msg) {
		if (msg instanceof TextMessage) {
			String message = ((TextMessage) msg).getContent();
			
			// �ber neue Nachricht informieren
			fireAddLine(message);
		}
	}

	

	 private void  send__wrappee__Base  (String msg) {
		send(new TextMessage(msg));
	}

	
	
	 private void  send__wrappee__Caesar  (String msg) {
		send__wrappee__Base(crypt.getEncryptedMessage(msg));
	}

	
	
	public void send(String msg) {
		send__wrappee__Caesar(crypt.getEncryptedMessage(msg));		
	}

	

	public void send(TextMessage msg) {
		try {
			outputStream.writeObject(msg);
			outputStream.flush();
		} catch (IOException ex) {
			ex.printStackTrace();
			thread.stop();
		}
	}

	

	/**
	 * fire Listner method for the observer pattern
	 */
	 private void  fireAddLine__wrappee__Base  (String line) {
	
	}

	
	
	 private void  fireAddLine__wrappee__GUI  (String line) {
		fireAddLine__wrappee__Base(line);
		gui.onMessageReceived(line);
	}

		

	 private void  fireAddLine__wrappee__History  (String line) {
		fireAddLine__wrappee__GUI(line);
		history.onMessageReceived(line);
	}

	
	
	 private void  fireAddLine__wrappee__Caesar  (String line) {
		fireAddLine__wrappee__History(crypt.getDecryptedMessage(line));
	}

		

	 private void  fireAddLine__wrappee__Console  (String line) {
		fireAddLine__wrappee__Caesar(line);
		System.out.println(line);
	}

	
	
	public void fireAddLine(String line) {
		fireAddLine__wrappee__Console(crypt.getDecryptedMessage(line));
	}

	

	public void stop() {
		thread.stop();
	}

	

	private Gui gui;

	

	History history;

	

	String password = "PASSWORD";

	
	
	ReverseEncryption crypt  = new ReverseEncryption();


}
