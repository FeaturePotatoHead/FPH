

import java.awt.Color; 
import java.io.IOException; 
import java.io.ObjectInputStream; 
import java.io.ObjectOutputStream; 
import java.net.Socket; 

public   class  Connection  extends Thread  implements ConnectionInterface {
	
	protected Socket socket;

	

	protected ObjectInputStream inputStream;

	

	protected ObjectOutputStream outputStream;

	

	protected Server server;

	
	protected boolean connectionOpen = true;

	

	public Connection(Socket s, Server server) {
		this.socket = s;
		try {
			inputStream = new ObjectInputStream((s.getInputStream()));
			outputStream = new ObjectOutputStream((s.getOutputStream()));
		} catch (IOException e) {
			e.printStackTrace();
		}

		this.server = server;
	}

	

	 private void  sendConnectedMessage__wrappee__Base  (String clientName) {
		TextMessage connectedMessage = new TextMessage(clientName + " has joined.");
			
		connectedMessage.setSender("Server");
		server.broadcast(connectedMessage);
		
		System.out.println(connectedMessage.getContent());
	}

	
	
	protected void sendConnectedMessage(String clientName) {
		sendConnectedMessage__wrappee__Base(clientName);
		TextMessage connectedMessage = new TextMessage(clientName + " has joined.");
		
		connectedMessage.setColor(Color.RED);
		connectedMessage.setSender("Server");
		server.broadcast(connectedMessage);
	}

	
	
	 private void  sendDisconnectedMessage__wrappee__Base  (String clientName) {
		TextMessage message = new TextMessage(clientName + " has left.");
			
		server.removeConnection(this);
		server.broadcast(message);
	}

	
	
	protected void sendDisconnectedMessage(String clientName) {
		sendDisconnectedMessage__wrappee__Base(clientName);

		TextMessage message = new TextMessage(clientName + " has left.");
		
		message.setColor(Color.RED);
		server.removeConnection(this);
		server.broadcast(message);
	}

	
	
	/**
	 * waits for incoming messages from the socket
	 */
	 private void  run__wrappee__Base  () {
		String clientName = socket.getInetAddress().toString();
		try {
			sendConnectedMessage(clientName);
			
			while (connectionOpen) {
				try {
					Object msg = inputStream.readObject();
					handleIncomingMessage(clientName, msg);
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				}
			}
		} catch (IOException ex) {
			//ex.printStackTrace();
		} finally {
			sendDisconnectedMessage(clientName);
			try {
				socket.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}

	

	public void run() {
		run__wrappee__Base();
		String clientName = socket.getInetAddress().toString();
		try {			
			while (connectionOpen) {
				try {
					Object msg = inputStream.readObject();
					handleIncomingMessage(clientName, msg);
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				}
			}
		} catch (IOException ex) {
			//ex.printStackTrace();
		} finally {
			sendDisconnectedMessage(clientName);
			try {
				socket.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}

	

	/**
	 * decides what to do with incoming messages
	 * 
	 * @param name
	 *            name of the client
	 * @param msg
	 *            received message
	 */
	 private void  handleIncomingMessage__wrappee__Base  (String name, Object msg) {
		if (msg instanceof TextMessage) {
			((TextMessage)msg).setSender(name);
			server.broadcast((TextMessage)msg);
		}
	}

	

	protected void handleIncomingMessage(String name, Object msg) {
		if (msg instanceof TextMessage && authentificated) { handleIncomingMessage__wrappee__Base(name, msg); }
		
		if (msg instanceof ConnectionMessage) {
			ConnectionMessage connectionMessage = (ConnectionMessage)msg;
			
			if (connectionMessage.getPassword() == server.getPasswordHash()) {
				this.authentificated = true;
				
				sendConnectedMessage(socket.getInetAddress().toString());
			} else {
				this.server.removeConnection(this);
				this.connectionOpen = false;
				try {
					socket.close();
				} catch (IOException e) {
					//e.printStackTrace();
				}
			}
		}
	}

	

	public void send(TextMessage msg) {
		try {
			synchronized (outputStream) {
				System.out.println("CONNECTION SEND: " + msg.getContent());
				outputStream.writeObject(msg);
			}
			outputStream.flush();
		} catch (IOException ex) {
			connectionOpen = false;
		}
	}

	
	protected boolean authentificated = false;


}
