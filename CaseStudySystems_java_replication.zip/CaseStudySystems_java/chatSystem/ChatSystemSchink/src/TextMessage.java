

import java.awt.Color; 

public   class  TextMessage  extends ChatMessage {
	

	private static final long serialVersionUID = 2191809085095630164L;

	
		
	protected String content;

	

	public TextMessage(String content) {
		this.content = content;
	}

	

	public String getContent() {
		return content;
	}

	
	
	protected void setContent(String content) {
		this.content = content;
	}

	

	protected Color color = Color.BLACK;

	
	
	public Color getColor() {
		return color;
	}

	
	
	public void setColor(Color color) {
		this.color = color;
	}


}
