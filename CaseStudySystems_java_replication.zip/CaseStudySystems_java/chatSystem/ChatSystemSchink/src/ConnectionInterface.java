

public  interface  ConnectionInterface {
	
	public void send(TextMessage msg);


}
