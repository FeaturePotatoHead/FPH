

import java.awt.Color; 

public   class  EncryptedTextMessage  extends TextMessage {
	

	private static final long serialVersionUID = -7194234609367496025L;

	

	protected int clearTextLength;

	
	protected int clearSenderLength;

	
	
	public EncryptedTextMessage(String content) {
		super(content);
		
		this.clearTextLength = content.length();
		
		setContent(encryptMessage(content));
	}

	

	public EncryptedTextMessage(String content, Color color) {
		super(content);
		
		this.clearTextLength = content.length();
		
		setContent(encryptMessage(content));
	}

	
	
	public void setSender(String sender) {
		super.setSender(encryptMessage(sender));
		clearSenderLength = sender.length();
	}

	
	
	public String getSender(int key) {
		return decryptMessage(super.getSender(), key, clearSenderLength);
	}

	
	
	public String getContent(int key) {
		return decryptMessage(super.getContent(), key, clearTextLength);
	}

	
	
	private String encryptMessage(String text) {
		return encryptMessage(text, 13);
	}

	
	
	 private String  encryptMessage__wrappee__EncryptionBase  (String text, int shift) {
		return text;
	}

	

	 private String  encryptMessage__wrappee__Ceasar  (String text, int shift) {
		int pos = 1;
		
		text = cesar(text, shift);
		
		return encryptMessage__wrappee__EncryptionBase(text, shift);
	}

	

	protected String encryptMessage(String text, int shift) {
		int pos = 1;
				
		if ((shift % text.length()) != 0) {
			pos = shift % text.length();
		}
		text = transposition(text, pos);
		
		return encryptMessage__wrappee__Ceasar(text, shift);
	}

	
	
	 private String  decryptMessage__wrappee__EncryptionBase  (String text, int key, int textLength) {
		return text;
	}

	
	
	 private String  decryptMessage__wrappee__Ceasar  (String text, int key, int textLength) {			decryptMessage__wrappee__EncryptionBase(text,key,textLength);
		text = cesarReverse(text, key);
		
		return text;
	}

	
	
	protected String decryptMessage(String text, int key, int textLength) {
		decryptMessage__wrappee__Ceasar(text,key,textLength);
		text = transpositionReverse(text, key % textLength);
		
		while (text.length() > 0 && text.charAt(text.length() - 1) == ' ') {
			text = text.substring(0, text.length() - 1);
		}
		
		return text;
	}

	

	private String cesar(String message, int shift) {

		String encryption = "";
		
		for (int c=0; c < message.length(); c++) {
			encryption += (char)((((int)message.charAt(c)) + 127 + shift) % 127);
		}
		
		return encryption;
	}

	

	private String cesarReverse(String message, int shift) {
		return cesar(message, -shift);
	}

	

	private String transposition(String message, int shift) {
		String encryption = "";
		
		while (shift != 1 && shift != 0 && message.length() % shift != 0) {
			message += " ";
		}		
		
		for (int start=0; start <= shift - 1; start++) {
			int pos = start;
			
			while (pos < message.length()) {
				encryption += message.charAt(pos);
				pos += shift;
			}
			
			if ((pos - shift) == message.length() - 1) {
				break;
			}
		}
		
		return encryption;
	}

	
	
	private String transpositionReverse(String message, int shift) {
		if (shift != 1 && shift > 0) {
			shift = message.length() / shift;
		}
		
		return transposition(message, shift);
	}


}
