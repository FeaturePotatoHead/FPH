

import java.awt.Color; 
import java.io.IOException; 
import java.io.ObjectInputStream; 
import java.io.ObjectOutputStream; 
import java.net.Socket; 
import java.util.ArrayList; 
import java.util.Iterator; 

public   class  Client  implements Runnable {
	
	public static void main(String args[]) throws IOException {
		if (args.length != 2)
			throw new RuntimeException("Syntax: ChatClient <host> <port>");

		Client client = new Client(args[0], Integer.parseInt(args[1]));
		
		new Gui("Chat " + args[0] + ":" + args[1], client);
	}

	

	protected ObjectInputStream inputStream;

	

	protected ObjectOutputStream outputStream;

	

	protected Thread thread;

	
	
	protected boolean error = false;

	
	protected boolean stop = false;

	

	public Client(String host, int port) {
		try {			
			System.out.println("Connecting to " + host + " (port " + port
					+ ")...");
			Socket s = new Socket(host, port);
			this.outputStream = new ObjectOutputStream((s.getOutputStream()));
			this.inputStream = new ObjectInputStream((s.getInputStream()));
			thread = new Thread(this);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	
	public void start() {	
			thread.start();
	}

	

	/**
	 * main method. waits for incoming messages.
	 */
	 private void  run__wrappee__Base  () {
		try {
			while (!(error || stop)) {
				try {
					Object msg = inputStream.readObject();
					System.out.println("RECEIVED");
					handleIncomingMessage(msg);
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			thread = null;
			try {
				outputStream.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}

	

	 private void  run__wrappee__History  () {
		run__wrappee__Base();
		addLineListener(new HistoryWriter("clientHistory"));
		
		try {
			while (!(error || stop)) {
				try {
					Object msg = inputStream.readObject();
					handleIncomingMessage(msg);
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (IOException ex) {
			//ex.printStackTrace();
		} finally {
			thread = null;
			try {
				outputStream.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}

	

	public void run() {
		send(new ConnectionMessage("password"));
		
		run__wrappee__History();
	}

	

	 private String  getMessageContent__wrappee__Base  (TextMessage msg) {
		TextMessage message = (TextMessage)msg;
		String text = "";

		text += message.getSender() + " wrote : ";
		text += message.getContent();
		
		return text;
	}

	
	
	protected String getMessageContent(TextMessage msg) {
		getMessageContent__wrappee__Base(msg);
		TextMessage message = (TextMessage)msg;
		String text = "";
		
		if (msg instanceof EncryptedTextMessage) {
			EncryptedTextMessage eMessage = (EncryptedTextMessage)message;
			text += eMessage.getSender(13) + " wrote : ";
			text += eMessage.getContent(13);
		} else {
			text += message.getSender() + " wrote : ";
			text += message.getContent();
		}
		
		return text;
	}

	
	
	 private void  propagateMessage__wrappee__Base  (TextMessage msg) {
		fireAddLine(getMessageContent(msg) + "\n");
	}

	

	protected void propagateMessage(TextMessage msg) {
		propagateMessage__wrappee__Base(msg);
		fireAddLine(getMessageContent(msg) + "\n", msg.getColor());
	}

	
	
	/**
	 * decides what to do with incoming messages
	 * 
	 * @param msg
	 *            the message (Object) received from the sockets
	 */
	protected void handleIncomingMessage(Object msg) {
		System.out.println(msg + ":" + (msg instanceof TextMessage));
		if (msg instanceof TextMessage) {
			propagateMessage((TextMessage)msg);
		}
	}

	
	
	 private void  send__wrappee__Base  (String line) {
		TextMessage message = new TextMessage(line);
			
		send(message);
	}

	
	
	public void send(String line) {
		EncryptedTextMessage msg = new EncryptedTextMessage(line);
		send__wrappee__Base(line);
		send(msg);
	}

	

	public void send(ChatMessage msg) {
		try {
			outputStream.writeObject(msg);
			outputStream.flush();
		} catch (IOException ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
			error = true;
		}
	}

	

	/**
	 * listener-list for the observer pattern
	 */
	protected ArrayList listeners = new ArrayList();

	

	/**
	 * addListner method for the observer pattern
	 */
	public void addLineListener(ChatLineListener listener) {
		listeners.add(listener);
	}

	

	/**
	 * removeListner method for the observer pattern
	 */
	public void removeLineListener(ChatLineListener listner) {
		listeners.remove(listner);
	}

	

	/**
	 * fire Listner method for the observer pattern
	 */
	public void fireAddLine(String line) {
		System.out.println("FIRE: " + listeners.size());
		for (Iterator iterator = listeners.iterator(); iterator.hasNext();) {
			ChatLineListener listener = (ChatLineListener) iterator.next();
			listener.newChatLine(line);
		}
	}

	

	public void stop() {
		stop = true;
	}

	
	
	public void fireAddLine(String line, Color color) {
		for (Iterator iterator = listeners.iterator(); iterator.hasNext();) {
			ChatLineListener listener = (ChatLineListener) iterator.next();
			listener.newChatLine(line, color);
		}
	}

	
	
	public void send(String line, Color color) {
		TextMessage msg = new TextMessage(line);
		msg.setColor(color);
		send(msg);
	}


}
