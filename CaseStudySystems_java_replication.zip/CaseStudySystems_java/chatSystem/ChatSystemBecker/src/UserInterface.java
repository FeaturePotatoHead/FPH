

import javax.swing.JFrame; 
import javax.swing.JPanel; 
import javax.swing.JTextField; 
import javax.swing.JTextArea; 
import javax.swing.JScrollPane; 
import javax.swing.BorderFactory; 
import javax.swing.DefaultComboBoxModel; 
import javax.swing.border.BevelBorder; 
import java.awt.event.ActionEvent; 
import java.awt.event.ActionListener; 

import javax.swing.JComboBox; 
import java.awt.Color; 
public   class  UserInterface  implements ChatLineListener {
	
	Client client;

	
	
	public UserInterface(Client client){
		this.client=client;	
		initUI();
	
	}

	
	
	 private void  newChatLine__wrappee__Basic  (String line){
	
	}

	

	 private void  newChatLine__wrappee__CUI  (String line){
		newChatLine__wrappee__Basic(line);
		System.out.println(line+"\n");
	}

	
	
	
	public void newChatLine(String line){
		newChatLine__wrappee__CUI(line);
		jTextArea.append(line);
	}

	
	
	 private void  initUI__wrappee__Basic  (){
		client.addLineListener(this);
		
	}

	
	
	
	 private void  initUI__wrappee__GUI  (){
		
		frame=new JFrame();
		initUI__wrappee__Basic();
		frame.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setPreferredSize(new java.awt.Dimension(408, 315));
		{
				frame.setSize(408, 320);
				frame.setVisible(true);
				jScrollPane = new JScrollPane();
				frame.getContentPane().add(jScrollPane);
				jScrollPane.setBounds(12, 12, 368, 196);
				{
					jTextArea = new JTextArea();
					jScrollPane.setViewportView(jTextArea);
					jTextArea.setBounds(12, 12, 368, 196);
					jTextArea.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
					jTextArea.setEditable(false);
				}
		}
		{
				
				jTextField = new JTextField();
				jTextField.setText("");
				frame.getContentPane().add(jTextField);
				
				jTextField.setBounds(12, 220, 368, 21);
				
				jTextField.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent evt) {
						jTextField1ActionPerformed(evt);
					}
				});
		}
		{
				jPanel_add = new JPanel();
				frame.getContentPane().add(jPanel_add);
				jPanel_add.setBounds(12, 247, 368, 34);
		
		}
		frame.pack();
		frame.setVisible(true);
		
		
	}

	
	public void initUI(){
		initUI__wrappee__GUI();
		farbauswahl=new JComboBox(new DefaultComboBoxModel(new String[] { "Schwarz", "Rot", "Blau", "Gr�n", "Gelb" }));
		jPanel_add.add(farbauswahl);
	}

	
	private JFrame frame;

	
	private JPanel jPanel;

	
	public JPanel jPanel_add;

	
	public JTextField jTextField;

	
	public JTextArea jTextArea;

	
	private JScrollPane jScrollPane;

	
	
	 private void  handleMessage__wrappee__GUI  (){
		client.send(jTextField.getText());
		jTextField.setText("");
	}

	
	
	
	/*	
	public void newChatLine(String line){
			jTextArea.append(line);
	}
	*/
	
	public void handleMessage(){
		handleMessage__wrappee__GUI();
		TextMessage msg=new ColorMessage(jTextField.getText());
		((ColorMessage) msg).setColor(farbauswahl.getSelectedItem().toString());
		client.send(msg);
		jTextField.setText("");
	}

	
	
	 private void  jTextField1ActionPerformed__wrappee__GUI  (ActionEvent evt) {
		handleMessage();
		/*
		
		client.send(jTextField.getText());
		jTextField.setText("");
		*/
	}

	
	
	private void jTextField1ActionPerformed(ActionEvent evt) {
		
		TextMessage msg=new ColorMessage(jTextField.getText());
		((ColorMessage) msg).setColor(farbauswahl.getSelectedItem().toString());
		client.send(msg);
		jTextField.setText("");
	}

	

	private JComboBox farbauswahl;

	
	private JPanel panel;


}
