


public  class  AuthMessage  extends TextMessage {
	

	public AuthMessage(String passwort){
		super(passwort);
	}


}
