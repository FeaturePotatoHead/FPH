

public  interface  ChatLineListener {
	
	void newChatLine(TextMessage msg);


}
