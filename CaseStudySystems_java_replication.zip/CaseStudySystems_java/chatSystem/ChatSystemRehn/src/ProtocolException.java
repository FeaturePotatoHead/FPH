

public  class  ProtocolException  extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4434795936421707441L;

	

	public ProtocolException(String line) {
		super(line);
	}


}
