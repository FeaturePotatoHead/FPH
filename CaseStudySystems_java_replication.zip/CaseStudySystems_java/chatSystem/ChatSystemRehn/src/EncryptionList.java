


import java.util.LinkedList; 

public   class  EncryptionList {
	
	public LinkedList methods = new LinkedList();

	
	public EncryptionList  () {
		methods.add(new Rot13Encryption());
	
		methods.add(new ReverseEncryption());
	}


}
