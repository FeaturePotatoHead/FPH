// $Header: /home/apel/cvs/fstcomp/examples/Java/Graph/Weight/Graph/Weight.java,v 1.1 2010-03-29 20:44:20 apel Exp $
/**
 * Please complete these missing tags
 * @author
 * @rref
 * @copyright
 * @concurrency
 * @see
 */
package Graph; 

 

class  Weight {
	
    int w = 0;

	
    /**
     * Please complete the missing tags for Weight
     * @param
     * @return
     * @throws
     * @pre
     * @post
     */
    Weight( int _w )
    {
        w = _w;
    }

	
    /**
     * Please complete the missing tags for print
     * @param
     * @return
     * @throws
     * @pre
     * @post
     */
    void print()
    {
        System.out.print( w );
    }


}
