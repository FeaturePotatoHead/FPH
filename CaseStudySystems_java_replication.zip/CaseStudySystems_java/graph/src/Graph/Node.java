// $Header: /home/apel/cvs/fstcomp/examples/Java/Graph/Color/Graph/Node.java,v 1.1 2010-03-29 20:44:20 apel Exp $
/**
 * Please complete these missing tags
 * @author
 * @rref
 * @copyright
 * @concurrency
 * @see
 */
package Graph; 

 

class  Node {
	
    int id = 0;

	
    /**
     * Please complete the missing tags for Node
     * @param
     * @return
     * @throws
     * @pre
     * @post
     */
    Node( int _id )
    {
        id = _id;
    }

	
    /**
     * Please complete the missing tags for print
     * @param
     * @return
     * @throws
     * @pre
     * @post
     */
     private void  print__wrappee__BasicGraph  ()
    {
        System.out.print( id );
    }

	
    /**
     * Please complete the missing tags for print
     * @param
     * @return
     * @throws
     * @pre
     * @post
     */
     private void  print__wrappee__Recursive  ()
    {
        print__wrappee__BasicGraph();
        if( childGraph != null )
        {
            System.out.print( " ++ " );
            childGraph.print();
            System.out.print( " -- " );
        }
    }

	
    /**
     * Please complete the missing tags for print
     * @param
     * @return
     * @throws
     * @pre
     * @post
     */
    void print()
    {
        Color.setDisplayColor( color );
        print__wrappee__Recursive();
    }

	
    private Graph childGraph = null;

	
    /**
     * Please complete the missing tags for getChildGraph
     * @param
     * @return
     * @throws
     * @pre
     * @post
     */
    Graph getChildGraph()
    {
        return childGraph;
    }

	
    /**
     * Please complete the missing tags for setChildGraph
     * @param
     * @return
     * @throws
     * @pre
     * @post
     */
    void setChildGraph( Graph g )
    {
        childGraph = g;
    }

	
    Color color = new Color( 815 );


}
