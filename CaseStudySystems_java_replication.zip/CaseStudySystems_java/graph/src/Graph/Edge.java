// $Header: /home/apel/cvs/fstcomp/examples/Java/Graph/Color/Graph/Edge.java,v 1.1 2010-03-29 20:44:20 apel Exp $
/**
 * Please complete these missing tags
 * @author
 * @rref
 * @copyright
 * @concurrency
 * @see
 */
package Graph; 

 

class  Edge {
	
	
    Node a;

	
    Node b;

	
    /**
     * Please complete the missing tags for Edge
     * @param
     * @return
     * @throws
     * @pre
     * @post
     */
    Edge( Node _a, Node _b )
    {
        a = _a;
        b = _b;
    }

	
    /**
     * Please complete the missing tags for print
     * @param
     * @return
     * @throws
     * @pre
     * @post
     */
     private void  print__wrappee__BasicGraph  ()
    {
        System.out.print( "edge (" );
        a.print();
        System.out.print( ", " );
        b.print();
        System.out.print( ") " );
    }

	
    /**
     * Please complete the missing tags for print
     * @param
     * @return
     * @throws
     * @pre
     * @post
     */
     private void  print__wrappee__Weight  ()
    {
        print__wrappee__BasicGraph();
        System.out.print( " [" );
        w.print();
        System.out.print( "] " );
    }

	
    /**
     * Please complete the missing tags for print
     * @param
     * @return
     * @throws
     * @pre
     * @post
     */
    void print()
    {
        Color.setDisplayColor( color );
        print__wrappee__Weight();
    }

	
    Weight w = new Weight( 0 );

	
    /**
     * Please complete the missing tags for setWeight
     * @param
     * @return
     * @throws
     * @pre
     * @post
     */
    void setWeight( Weight _w )
    {
        w = _w;
    }

	
    Color color = new Color( 4711 );


}
