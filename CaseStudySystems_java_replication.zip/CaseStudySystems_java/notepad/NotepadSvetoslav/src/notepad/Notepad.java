package notepad; 
/**
 *This is a JAVA� program for writing, opening, saving, editing the documents,
 *has the ability to copy, cut, paste & select all text in the JTextArea,
 *has @see ExampleFileFilter class (From SUN� -http://java.sun.com-) for filter the file
 *has a print class (from AarbTeam2000� -http://wwww.arabteam2000.com-) for printing the documents
 */

/**
 *@King Fahd University of Petroleum and Minerals (KFUPM)
 *@auther: Al-Thubaiti Salah
 *@ICS201 PROJECT
 *@JAVA� Notepad (JNotepad)
 *@version# 2.0
 */
 
//import the packages for using the classes in them into the program
import java.awt.Container; 
import java.awt.event.ActionEvent; 
import java.awt.event.ActionListener; 
import java.awt.event.KeyEvent; 
import java.awt.event.WindowAdapter; 
import java.awt.event.WindowEvent; 

import javax.swing.ImageIcon; 
import javax.swing.JButton; 

import javax.swing.JFrame; 
import javax.swing.JMenu; 
import javax.swing.JMenuBar; 
import javax.swing.JMenuItem; 
import javax.swing.JScrollPane; 
import javax.swing.JTextArea; 
import javax.swing.JToolBar; 
import javax.swing.KeyStroke; 

import javax.swing.JCheckBoxMenuItem; 

import javax.swing.event.UndoableEditEvent; 
import javax.swing.event.UndoableEditListener; 
import javax.swing.undo.UndoManager; 

public 

class  Notepad  extends JFrame {
	
	public static final long serialVersionUID = 1L;

	
	//for using the methods in these classes
	public Actions actions = new Actions(this);

	
	public Center center = new Center(this);

	
	//declaration of the private variables used in the program
	//create the text area
	private JTextArea textArea;

	
	//create the Menu Bar that contains the JMenu "filE, ediT, formaT, helP"
	private JMenuBar menubar;

	
	//Create the menu that contains the items
	private JMenu filE, ediT;

	
	//Create the menu items
	private JMenuItem neW, opeN, savE, saveAS, prinT, exiT;

	
	//Create the Tool Bar that contains the JButton
	private JToolBar toolBar;

	
	//Create the buttons
	private JButton newButton, openButton, saveButton, saveAsButton, printButton;

	
	//Create Scroll pane (JScrollPane) for the JTextArea
	private JScrollPane scrollpane;

	
	
	public JTextArea getTextArea(){
		return textArea;
	}

	
	
	//initialization
	public Notepad  (){
		//set the title for Notepad and set the size for it.
		setTitle("Untitled - JAVA� Notepad");
		setSize(800,600);
		//get the graphical user interface components display area
		Container cp = getContentPane();
		//adding the text area,
		//adding the tool bar &
		//adding the scroll pane to the container
		cp.add(textArea = new JTextArea());
		cp.add("North", toolBar = new JToolBar("Tool Bar"));
		cp.add(scrollpane = new JScrollPane(textArea)); 
		//for setting the menu bar
		setJMenuBar(menubar= new JMenuBar());
		//adding file
		menubar.add(filE   = new JMenu("File"));
		//adding neW, opeN, savE, saveAS, prinT & exiT to the filE Menu
		filE.add(neW    = new JMenuItem("New", new ImageIcon(this.getClass().getResource("images/new.gif"))));
		filE.add(opeN   = new JMenuItem("Open", new ImageIcon(this.getClass().getResource("images/open.gif"))));
		filE.add(savE   = new JMenuItem("Save", new ImageIcon(this.getClass().getResource("images/save.gif"))));
		filE.add(saveAS = new JMenuItem("Save As", new ImageIcon(this.getClass().getResource("images/saveAs.gif"))));
		filE.add(prinT  = new JMenuItem("Print", new ImageIcon(this.getClass().getResource("images/print.gif"))));
		filE.add(exiT   = new JMenuItem("Exit"));
		filE.insertSeparator(4);
		filE.insertSeparator(6);
		//allowing the file   menu to be selected by pressing ALT + F
		filE.setMnemonic('f');
		//allowing the neW       menu item to be selected by pressing ALT + N
		neW.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, ActionEvent.CTRL_MASK));
		//allowing the opeN      menu item to be selected by pressing ALT + O
		opeN.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, ActionEvent.CTRL_MASK));
		//allowing the savE      menu item to be selected by pressing ALT + S
		savE.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, ActionEvent.CTRL_MASK));
		//allowing the prinT     menu item to be selected by pressing ALT + P
		prinT.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P, ActionEvent.CTRL_MASK));
		//allowing the exiT      menu item to be selected by pressing ALT + F4
		exiT.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F4, ActionEvent.CTRL_MASK));
		//adding newButton, openButton, saveButton, saveAsButton, printButton
		toolBar.add(newButton   = new JButton(new ImageIcon(this.getClass().getResource("images/new.gif"))));
		toolBar.add(openButton  = new JButton(new ImageIcon(this.getClass().getResource("images/open.gif"))));
		toolBar.add(saveButton  = new JButton(new ImageIcon(this.getClass().getResource("images/save.gif"))));
		toolBar.add(saveAsButton= new JButton(new ImageIcon(this.getClass().getResource("images/saveAs.gif"))));
		toolBar.add(printButton = new JButton(new ImageIcon(this.getClass().getResource("images/print.gif"))));
		toolBar.addSeparator();
		//adding a tool tip text to the button for descriping the image icon.
		newButton.setToolTipText("New");
		openButton.setToolTipText("Open");
		saveButton.setToolTipText("Save");
		saveAsButton.setToolTipText("Save As");
		printButton.setToolTipText("Print");
		//setting the default close operation to false & using own action (exiT action @Actions.java)
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e){
				actions.exiT();
			}
		});
		//adding action listener for menu item: neW, opeN, savE, saveAS, prinT, exiT,
		neW.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				actions.neW();
			}
		});
		opeN.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				actions.opeN();
			}
		});
		savE.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				actions.savE();
			}
		});
		saveAS.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				actions.saveAs();
			}
		});
		prinT.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				actions.prinT();
			}
		});
		
		exiT.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				actions.exiT();
			}
		});
		//adding action listener for the button in the tool bar: newButton, openButton,
		//saveButton, saveAsButton, printButtom
		newButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				actions.neW();
			}
		});
		openButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				actions.opeN();
			}
		});
		saveButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				actions.savE();
			}
		});
		saveAsButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				actions.saveAs();
			}
		});
		printButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				actions.prinT();
			}
		});
		//Setting the Line Wrap & Wrap Style Word features are true 
		textArea.setLineWrap(true);
		textArea.setWrapStyleWord(true);
		center.nCenter();
		setVisible(true);
	
		//MENU
		//menu items
		//find
		finD = new JMenuItem("Find", new ImageIcon(this.getClass().getResource("images/find.gif")));
		finD.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F, ActionEvent.CTRL_MASK));
		//find next
		findNexT = new JMenuItem("Find Next");
		findNexT.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F3, ActionEvent.CTRL_MASK));
		//add items to menu
		if (ediT == null) {
			ediT = new JMenu("Edit");
		}
		ediT.add(finD);
		ediT.add(findNexT);
		ediT.addSeparator();
		menubar.add(ediT);
		//find
		finD.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				actions.finD();
			}
		});
		//find next
		findNexT.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				actions.findNexT();
			}
		});
		
		//TOOLBAR
		//find
		toolBar.add(findButton  = new JButton(new ImageIcon(this.getClass().getResource("images/find.gif"))));
		toolBar.addSeparator();
		//button listeners
		//find
	    findButton.setToolTipText("Find");
      //button/menu listeners
		findButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				actions.finD();
			}
		});
	
  	      //MENU
		//menu items
		//cut
		cuT = new JMenuItem("Cut",  new ImageIcon(this.getClass().getResource("images/cut.gif")));
		cuT.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, ActionEvent.CTRL_MASK));
		//copy
		copY = new JMenuItem("Copy", new ImageIcon(this.getClass().getResource("images/copy.gif")));
		copY.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, ActionEvent.CTRL_MASK));
		//paste
		pastE= new JMenuItem("Paste",new ImageIcon(this.getClass().getResource("images/paste.gif")));
		pastE.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V, ActionEvent.CTRL_MASK));
		//select all 
		selectALL= new JMenuItem("Select All");
		selectALL.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, ActionEvent.CTRL_MASK));
		//add items to menu
		if (ediT == null) {
			ediT = new JMenu("Edit");
		}
		ediT.add(cuT);
		ediT.add(copY);
		ediT.add(pastE);
		ediT.add(selectALL);
		ediT.setMnemonic('e');
		menubar.add(ediT);
		ediT.addSeparator();
		//menu listeners
		//cut
		cuT.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				actions.cuT();
			}
		});
		//copy
		copY.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				actions.copY();
			}
		});
		//paste
		pastE.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				actions.pastE();
			}
		});
		//select all
		selectALL.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				actions.selectALL();
			}
		});

		//TOOLBAR
		//cut
		cutButton   = new JButton(new ImageIcon(this.getClass().getResource("images/cut.gif")));
		//copy
		copyButton  = new JButton(new ImageIcon(this.getClass().getResource("images/copy.gif")));
		//paste
		pasteButton = new JButton(new ImageIcon(this.getClass().getResource("images/paste.gif")));
		//add buttons to toolbar
		toolBar.add(cutButton);
		cutButton.setToolTipText("Cut");
		toolBar.add(copyButton);
		copyButton.setToolTipText("Copy");
		toolBar.add(pasteButton);
		pasteButton.setToolTipText("Paste");
		toolBar.addSeparator();
		//button listeners
		cutButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				actions.cuT();
			}
		});
		copyButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				actions.copY();
			}
		});
		pasteButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				actions.pastE();
			}
		});
	
		//MENU
		//menu items
		//font
		fonT = new JMenuItem("Font", new ImageIcon(this.getClass().getResource("images/font.gif")));
		//line wrap
		lineWraP = new JCheckBoxMenuItem("Line Wrap");
		//format
		formaT = new JMenu("Format");
		formaT.add(fonT);
		formaT.add(lineWraP);
		formaT.setMnemonic('o');
		// add items to menu
		menubar.add(formaT);
		//menu listeners
		//Format
		lineWraP.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				actions.lineWraP();
			}
		});
		fonT.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				actions.fonT();
			}
		});
		
		//TOOLBAR
		//font
		fontButton  = new JButton(new ImageIcon(this.getClass().getResource("images/font.gif")));
		fontButton.setToolTipText("Font");
		//add buttons to toolbar
		toolBar.add(fontButton);
		toolBar.addSeparator();
        //button/menu listeners
		fontButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				actions.fonT();
			}
		});
	
		//MENU
		if (ediT == null) {
			ediT = new JMenu("Edit");
		}
		//undo
		ediT.add(undoAction);
		//redo
		ediT.add(redoAction);
		ediT.addSeparator();
		menubar.add(ediT);
		//TOOLBAR
		//undo
		toolBar.add(undoAction);
		//redo
		toolBar.add(redoAction);
		toolBar.addSeparator();
		//button/menu listeners
		textArea.getDocument().addUndoableEditListener(new UndoableEditListener(){
			public void undoableEditHappened(UndoableEditEvent e){
				//Remember the edit and update the menus
				undo.addEdit(e.getEdit());
				undoAction.update();
				redoAction.update();
			}
		}); 
	
		//MENU
		//menu items
		//help
		helP   = new JMenu("Help");
		helP.add(abouT = new JMenuItem("About Notepad", new ImageIcon(this.getClass().getResource("images/about.gif"))));
		helP.setMnemonic('h');
		// add items to menu
		menubar.add(helP);
		//
		abouT.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				actions.abouT();
			}
		});
		//TOOLBAR
		//about
		aboutButton = new JButton(new ImageIcon(this.getClass().getResource("images/about.gif")));
		aboutButton.setToolTipText("About Notepad");
		//add buttons to toolbar
		toolBar.add(aboutButton);
		toolBar.addSeparator();
      	//button/menu listeners
		aboutButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				actions.abouT();
			}
		});		
	}

	
	//Main Method
	public static void main(String[] args){
		new Notepad();
	}

	
	//FIND FEATURE
	//fields 
  	private JMenuItem finD, findNexT;

	
	private JButton findButton;

	
	//fields 
	private JMenuItem cuT, copY, pastE, selectALL;

	
	private JButton cutButton, copyButton, pasteButton;

	
	//fields
	private JMenu formaT;

	
	private JMenuItem fonT;

	
	private JCheckBoxMenuItem lineWraP;

	
	private JButton fontButton;

	
	
	//for using lineWrap & textArea @Actions.java
	public JCheckBoxMenuItem getLineWrap(){
		return lineWraP;
	}

		
	//fields 
	private UndoManager undo = new UndoManager();

	
	private UndoAction undoAction = new UndoAction(this);

	
	private RedoAction redoAction = new RedoAction(this);

	
	
	public UndoManager getUndo() {
		return undo;
	}

	
	
	public RedoAction getRedoAction() {
		return redoAction;
	}

	
	public UndoAction getUndoAction() {
		return undoAction;
	}

	
	//HELP FEATURE
	//fields
	private JMenu helP;

	
	private JMenuItem abouT;

	
	private JButton aboutButton;


}
