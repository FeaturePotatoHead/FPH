

//import the packages for using the classes in them into the program
import java.awt.*; 
import java.awt.print.*; 
import javax.swing.*; 

/**
 *A class for creating a printer option.
 */
public   class  Print  implements Printable {
	
    private Component componentToBePrinted  ;

	

     private static void  printComponent__wrappee__Print  (Component c){
        new Print(c).print();
    }

	

    public static void printComponent(Component c){
	printComponent__wrappee__Print(c);
        new Print(c).print();
    }

	
    public Print  (Component componentToBePrinted){
        this.componentToBePrinted = componentToBePrinted;
    
        this.componentToBePrinted = componentToBePrinted;
    }

	
     private void  print__wrappee__Print  (){
        PrinterJob printJob = PrinterJob.getPrinterJob();
        printJob.setPrintable(this);
        if(printJob.printDialog())
        try{
            printJob.print();
        }
        catch(PrinterException pe){
            System.out.println("Error printing: " + pe);
        }
    }

	
    public void print(){
	print__wrappee__Print();
        PrinterJob printJob = PrinterJob.getPrinterJob();
        printJob.setPrintable(this);
        if(printJob.printDialog())
        try{
            printJob.print();
        }
        catch(PrinterException pe){
            System.out.println("Error printing: " + pe);
        }
    }

	
     private int  print__wrappee__Print  (Graphics g, PageFormat pageFormat, int pageIndex){
        if(pageIndex > 0){
            return(NO_SUCH_PAGE);
        }
        else{
            Graphics2D g2d = (Graphics2D)g;
            g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY());
            disableDoubleBuffering(componentToBePrinted);
            componentToBePrinted.paint(g2d);
            enableDoubleBuffering(componentToBePrinted);
            return(PAGE_EXISTS);
        }
    }

	
    public int print(Graphics g, PageFormat pageFormat, int pageIndex){
	print__wrappee__Print(g, pageFormat, pageIndex);
        if(pageIndex > 0){
            return(NO_SUCH_PAGE);
        }
        else{
            Graphics2D g2d = (Graphics2D)g;
            g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY());
            disableDoubleBuffering(componentToBePrinted);
            componentToBePrinted.paint(g2d);
            enableDoubleBuffering(componentToBePrinted);
            return(PAGE_EXISTS);
        }
    }

	
     private static void  disableDoubleBuffering__wrappee__Print  (Component c){
        RepaintManager currentManager = RepaintManager.currentManager(c);
        currentManager.setDoubleBufferingEnabled(false);
    }

	
    public static void disableDoubleBuffering(Component c){
	disableDoubleBuffering__wrappee__Print(c);
        RepaintManager currentManager = RepaintManager.currentManager(c);
        currentManager.setDoubleBufferingEnabled(false);
    }

	
     private static void  enableDoubleBuffering__wrappee__Print  (Component c){
        RepaintManager currentManager = RepaintManager.currentManager(c);
        currentManager.setDoubleBufferingEnabled(true);
    }

	
    public static void enableDoubleBuffering(Component c){
	enableDoubleBuffering__wrappee__Print(c);
        RepaintManager currentManager = RepaintManager.currentManager(c);
        currentManager.setDoubleBufferingEnabled(true);
    }


}
