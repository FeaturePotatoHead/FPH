package tmp; 

public   interface  Exp {
	
  String toString();

	
  int eval();


}
