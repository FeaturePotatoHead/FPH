package tmp; 

public   class  Test {
	
  static Exp e;

	
   private static void  main__wrappee__base  (  String args[]){
  }

	
   private static void  main__wrappee__ToString  (  String args[]){
    Test.printtest();
    main__wrappee__base(args);
  }

	
  public static void main(  String args[]){
    main__wrappee__ToString(args);
    Test.evaltest();
  }

	
  static void printtest(){
    e=new Num(3);
    System.out.println("print(3) = " + e);
    e=new Neg(new Num(5));
    System.out.println("print(Neg(5)) = " + e);
    e=new Plus(new Num(5),new Num(7));
    System.out.println("print(5+7) = " + e);
  }

	
  static void evaltest(){
    e=new Num(1);
    System.out.println("eval(1) = " + e.eval());
    e=new Neg(new Num(1));
    System.out.println("eval(Neg(1)) = " + e.eval());
    e=new Plus(new Num(1),new Num(2));
    System.out.println("eval(1+2)=" + e.eval());
    e=new Neg(new Plus(new Num(1),new Num(2)));
    System.out.println("eval(-(1+2))=" + e.eval());
  }


}
