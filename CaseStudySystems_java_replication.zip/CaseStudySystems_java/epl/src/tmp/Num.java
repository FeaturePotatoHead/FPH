package tmp; 

public   class  Num  implements Exp {
	
  int value;

	
  Num(  int val){
    value=val;
  }

	
  public String toString(){
    return "" + value;
  }

	
  public int eval(){
    return value;
  }


}
