package generator; 


public  interface  GeneratorStrategy {
	
	
	 int getNext(int x, int y);

	
	String toString();


}
