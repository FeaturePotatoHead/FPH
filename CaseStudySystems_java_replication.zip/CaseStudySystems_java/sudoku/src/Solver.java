public  interface  Solver {
	

    public boolean trySolve(Board board);


}
