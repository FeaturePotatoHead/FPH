
/**
 *
 *
 */
public  class  NotSolvableException  extends Exception {
	

    /**
     *
     */
    public NotSolvableException() {

    }

	

    /**
     * @param msg
     *            Error message
     */
    public NotSolvableException(String msg) {
        super(msg);
    }


}
