
public  class  Sprach {
	
	public static String START = "Start";

	
	public static String HELP = "Helfen";

	
	public static String HelpItem="Item";

	
	public static String EXIT = "End";

	
	public static String LIAN_WANG = "1";

	
	public static String RESUME = "Resume";

	
	public static String NOTE = "Score";

	
	public static String MAIN_MENU = "main menu";

	
	public static String PAUSE = "Pause";

	
	public static String HNOTE = "Top score :";

	
	public static String Name = "Input Name";

	
	public static String LOSE = "Lose !";

	
	public static String LEVEL = "L E V E L ";

	
	public static String WIN = "W I N !";

	

	public static String TANKA = "Tank-A";

	
	public static String TANKB = "Tank-B";

	
	public static String TANKC = "Tank-C";


}
