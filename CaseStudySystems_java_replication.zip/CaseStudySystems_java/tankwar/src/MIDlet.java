
public  class  MIDlet {

}
