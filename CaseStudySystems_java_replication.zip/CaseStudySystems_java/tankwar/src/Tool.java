
public   class  Tool {
	
	
	 private void  init__wrappee__Beschleunigung  (TankManager tankManager, int x_Koordinate, int y_Koordinate, int toolType) {
		switch (toolType) {
		case 370:
			break;
		}
	}

	
	
	 private void  init__wrappee__einfrieren  (TankManager tankManager, int x_Koordinate, int y_Koordinate, int toolType) {
		init__wrappee__Beschleunigung(tankManager, x_Koordinate, y_Koordinate, toolType);
		switch (toolType) {
		case 371:
			break;
		}
	}

	
	
	 private void  init__wrappee__Bombe  (TankManager tankManager, int x_Koordinate, int y_Koordinate, int toolType) {
		init__wrappee__einfrieren(tankManager,x_Koordinate,y_Koordinate,toolType);
		switch (toolType) {
		case 374:
			break;
		}
	}

	
	
	 private void  init__wrappee__Energie  (TankManager tankManager, int x_Koordinate, int y_Koordinate, int toolType) {
		init__wrappee__Bombe(tankManager, x_Koordinate, y_Koordinate, toolType);
		switch (toolType) {
		case 373:
			break;
		}
	}

	
	
	 private void  init__wrappee__Feuerkraft  (TankManager tankManager, int x_Koordinate, int y_Koordinate, int toolType) {
		init__wrappee__Energie(tankManager, x_Koordinate, y_Koordinate, toolType);
		switch (toolType) {
		case 372:
			break;
		}
	}

	

	protected void init(TankManager tankManager, int x_Koordinate, int y_Koordinate, int toolType) {
		init__wrappee__Feuerkraft(tankManager, x_Koordinate, y_Koordinate, toolType);
		switch (toolType) {
		case 375:
			break;
		}
	}


}
