package de.ovgu.cide.jakutil;

public class ReturnHack {
	public static final ReturnObject returnObject = new ReturnObject(null);
	public static final ReturnInt returnInt = new ReturnInt(0);
	public static final ReturnBoolean returnBoolean = new ReturnBoolean(true);
	public static final ReturnVoid returnVoid = new ReturnVoid();
}
