package de.ovgu.cide.jakutil;

public class ReturnVoid extends RuntimeException {
}
