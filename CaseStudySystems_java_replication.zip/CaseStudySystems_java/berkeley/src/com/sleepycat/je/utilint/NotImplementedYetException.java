package com.sleepycat.je.utilint; 
import de.ovgu.cide.jakutil.*; 
/** 
 * Something is not yet implemented.
 */
public  class  NotImplementedYetException  extends RuntimeException {
	
  public NotImplementedYetException(){
    super();
  }

	
  public NotImplementedYetException(  String message){
    super(message);
  }


}
