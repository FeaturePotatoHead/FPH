package com.horstmann.violet; 

import com.horstmann.violet.framework.Edge; 
import com.horstmann.violet.framework.Graph; 
import com.horstmann.violet.framework.Node; 

public   class  StateDiagramGraph  extends Graph {
	
   public Node[] getNodePrototypes()
   {
      return NODE_PROTOTYPES;
   }

	

   public Edge[] getEdgePrototypes()
   {
      return EDGE_PROTOTYPES;
   }

	

   protected static final Node[] NODE_PROTOTYPES = new Node[4];

	

   protected static final Edge[] EDGE_PROTOTYPES = new Edge[2];

	
   static
   {
      EDGE_PROTOTYPES[1] = new NoteEdge();
   }

	
   static
   {
      EDGE_PROTOTYPES[0] = new StateTransitionEdge();
   }

	
   static
   {
      NODE_PROTOTYPES[3] = new NoteNode();
   }

	
   static
   {
      CircularStateNode finalState = new CircularStateNode();
      finalState.setFinal(true);
      NODE_PROTOTYPES[2] = finalState;     
   }

	
   static
   {
      NODE_PROTOTYPES[1] = new CircularStateNode();
   }

	
   static
   {
      NODE_PROTOTYPES[0] = new StateNode();
   }


}
