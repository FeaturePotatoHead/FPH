package com.horstmann.violet; 

import java.awt.geom.Point2D; 

import com.horstmann.violet.framework.Edge; 
import com.horstmann.violet.framework.Graph; 
import com.horstmann.violet.framework.Node; 

public   class  ClassDiagramGraph  extends Graph {
	

   public boolean connect(Edge e, Point2D p1, Point2D p2)
   {
      Node n1 = findNode(p1);
      Node n2 = findNode(p2);
      // if (n1 == n2) return false;
      return super.connect(e, p1, p2);
   }

	

   public Node[] getNodePrototypes()
   {
      return NODE_PROTOTYPES;
   }

	

   public Edge[] getEdgePrototypes()
   {
      return EDGE_PROTOTYPES;
   }

	

   protected static final Node[] NODE_PROTOTYPES = new Node[4];

	

   protected static final Edge[] EDGE_PROTOTYPES = new Edge[7];

	
   	static {
      EDGE_PROTOTYPES[6] = new NoteEdge();
   	}

	
   	static {
      ClassRelationshipEdge interfaceInheritance = new ClassRelationshipEdge();
      interfaceInheritance.setBentStyle(BentStyle.VHV);
      interfaceInheritance.setLineStyle(LineStyle.DOTTED);
      interfaceInheritance.setEndArrowHead(ArrowHead.TRIANGLE);
      EDGE_PROTOTYPES[2] = interfaceInheritance;
   	}

	
   	static {
      ClassRelationshipEdge composition = new ClassRelationshipEdge();
      composition.setBentStyle(BentStyle.HVH);
      composition.setStartArrowHead(ArrowHead.BLACK_DIAMOND);
      EDGE_PROTOTYPES[5] = composition;
   	}

	
   	static {
      ClassRelationshipEdge association = new ClassRelationshipEdge();
      association.setBentStyle(BentStyle.HVH);
      association.setEndArrowHead(ArrowHead.V);
      EDGE_PROTOTYPES[3] = association;
   	}

	
   	static {
      ClassRelationshipEdge aggregation = new ClassRelationshipEdge();
      aggregation.setBentStyle(BentStyle.HVH);
      aggregation.setStartArrowHead(ArrowHead.DIAMOND);
      EDGE_PROTOTYPES[4] = aggregation;
   	}

	
   	static {
      ClassRelationshipEdge inheritance = new ClassRelationshipEdge();
      inheritance.setBentStyle(BentStyle.VHV);
      inheritance.setEndArrowHead(ArrowHead.TRIANGLE);
      EDGE_PROTOTYPES[1] = inheritance;
   	}

	
   	static {
   	  ClassRelationshipEdge dependency = new ClassRelationshipEdge();
      dependency.setLineStyle(LineStyle.DOTTED);
      dependency.setEndArrowHead(ArrowHead.V);
      EDGE_PROTOTYPES[0] = dependency;
   	}

	
   	static {
   		NODE_PROTOTYPES[3] = new NoteNode();
   	}

	
   	static {
   		NODE_PROTOTYPES[2] = new PackageNode();
   	}

	
   	static {
   		NODE_PROTOTYPES[1] = new InterfaceNode();
   	}

	
   	static {
   		NODE_PROTOTYPES[0] = new ClassNode();
   	}


}
