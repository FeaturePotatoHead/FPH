package com.horstmann.violet; 

import com.horstmann.violet.framework.EditorFrame; 

import com.horstmann.violet.framework.VersionChecker; 

public   class  UMLEditor {
	
    private static void  main__wrappee__base  (String[] args)
   {
      try
      {
         System.setProperty("apple.laf.useScreenMenuBar", "true");
      }
      catch (SecurityException ex)
      {
         // well, we tried...
      }

      frame = new EditorFrame(UMLEditor.class);

      frame.setVisible(true);
   }

	
    private static void  main__wrappee__UseCaseDiagram  (String[] args)
   {
   	  main__wrappee__base(args);

      frame.addGraphType("usecase_diagram", UseCaseDiagramGraph.class);

   }

	
    private static void  main__wrappee__ObjectDiagram  (String[] args)
   {
   	  main__wrappee__UseCaseDiagram(args);

      frame.addGraphType("object_diagram", ObjectDiagramGraph.class);

   }

	
    private static void  main__wrappee__StateDiagram  (String[] args)
   {
   	  main__wrappee__ObjectDiagram(args);

      frame.addGraphType("state_diagram", StateDiagramGraph.class);

   }

	
    private static void  main__wrappee__SequenceDiagram  (String[] args)
   {
   	  main__wrappee__StateDiagram(args);

      frame.addGraphType("sequence_diagram", SequenceDiagramGraph.class);

   }

	
    private static void  main__wrappee__ClassDiagram  (String[] args)
   {
   	  main__wrappee__SequenceDiagram(args);

      frame.addGraphType("class_diagram", ClassDiagramGraph.class);

   }

	
    private static void  main__wrappee__Preferences  (String[] args)
   {
   	  main__wrappee__ClassDiagram(args);

      String laf = frame.preferences.get("laf", null);
      if (laf != null) frame.changeLookAndFeel(laf);
      
   }

	

    private static void  main__wrappee__VersionChecker  (String[] args)
   {
      VersionChecker checker = new VersionChecker();
      checker.check(JAVA_VERSION);

      main__wrappee__Preferences(args);
   }

	
   public static void main(String[] args)
   {
   	  main__wrappee__VersionChecker(args);

      frame.readArgs(args);
   }

	

   public static EditorFrame frame;

	

   private static final String JAVA_VERSION = "1.4";


}
