package com.horstmann.violet; 

import com.horstmann.violet.framework.Edge; 
import com.horstmann.violet.framework.Graph; 
import com.horstmann.violet.framework.Node; 

public   class  UseCaseDiagramGraph  extends Graph {
	

   public Node[] getNodePrototypes()
   {
      return NODE_PROTOTYPES;
   }

	

   public Edge[] getEdgePrototypes()
   {
      return EDGE_PROTOTYPES;
   }

	
   
   protected static final Node[] NODE_PROTOTYPES = new Node[3];

	

   protected static final Edge[] EDGE_PROTOTYPES = new Edge[5];

	
   static
   {
      EDGE_PROTOTYPES[4] = new NoteEdge();
   }

	
   static
   {
      ClassRelationshipEdge generalization =
         new ClassRelationshipEdge();
      generalization.setBentStyle(BentStyle.STRAIGHT);
      generalization.setLineStyle(LineStyle.SOLID);
      generalization.setEndArrowHead(ArrowHead.TRIANGLE);
      EDGE_PROTOTYPES[3] = generalization;
   }

	
   static
   {
      ClassRelationshipEdge includeRel =
         new ClassRelationshipEdge();
      includeRel.setBentStyle(BentStyle.STRAIGHT);
      includeRel.setLineStyle(LineStyle.DOTTED);
      includeRel.setEndArrowHead(ArrowHead.V);
      includeRel.setMiddleLabel("\u00ABinclude\u00BB");
      EDGE_PROTOTYPES[2] = includeRel;
   }

	
   static
   {
      ClassRelationshipEdge extendRel =
         new ClassRelationshipEdge();
      extendRel.setBentStyle(BentStyle.STRAIGHT);
      extendRel.setLineStyle(LineStyle.DOTTED);
      extendRel.setEndArrowHead(ArrowHead.V);
      extendRel.setMiddleLabel("\u00ABextend\u00BB");
      EDGE_PROTOTYPES[1] = extendRel;
   }

	
   static
   {
      ClassRelationshipEdge communication =
         new ClassRelationshipEdge();
      communication.setBentStyle(BentStyle.STRAIGHT);
      communication.setLineStyle(LineStyle.SOLID);
      communication.setEndArrowHead(ArrowHead.NONE);
      EDGE_PROTOTYPES[0] = communication;
   }

	
   static
   {
      NODE_PROTOTYPES[2] = new NoteNode();
   }

	
   static
   {
      NODE_PROTOTYPES[1] = new UseCaseNode();
   }

	
   static
   {
      NODE_PROTOTYPES[0] = new ActorNode();
   }


}
