package com.horstmann.violet; 

import com.horstmann.violet.framework.Edge; 
import com.horstmann.violet.framework.Graph; 
import com.horstmann.violet.framework.MultiLineString; 
import com.horstmann.violet.framework.Node; 

public   class  ObjectDiagramGraph  extends Graph {
	
   public Node[] getNodePrototypes()
   {
      return NODE_PROTOTYPES;
   }

	

   public Edge[] getEdgePrototypes()
   {
      return EDGE_PROTOTYPES;
   }

	

   protected static final Node[] NODE_PROTOTYPES = new Node[3];

	

   protected static final Edge[] EDGE_PROTOTYPES = new Edge[3];

	
   static
   {
      EDGE_PROTOTYPES[2] = new NoteEdge();
   }

	
   static
   {
      ClassRelationshipEdge association = new ClassRelationshipEdge();
      association.setBentStyle(BentStyle.STRAIGHT);
      EDGE_PROTOTYPES[1] = association;
   }

	
   static
   {
		EDGE_PROTOTYPES[0] = new ObjectReferenceEdge();
   }

	
   static
   {
      NODE_PROTOTYPES[2] = new NoteNode();
   }

	
   static
   {
      FieldNode f = new FieldNode();
      MultiLineString fn = new MultiLineString();
      fn.setText("name");
      f.setName(fn);
      MultiLineString fv = new MultiLineString();
      fv.setText("value");
      f.setValue(fv);
      NODE_PROTOTYPES[1] = f;
   }

	
   static
   {
		NODE_PROTOTYPES[0] = new ObjectNode();
   }


}
