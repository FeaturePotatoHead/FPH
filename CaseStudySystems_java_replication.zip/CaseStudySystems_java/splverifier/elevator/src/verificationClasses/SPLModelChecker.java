package verificationClasses
;
import java.util.Random;

public class SPLModelChecker {
	public static boolean getBoolean() {
		return new Random().nextBoolean();
	}

}
