package verificationClasses;

import java.util.Random;

public class SPLModelChecker {
	public static boolean getBoolean() {
		return new Random().nextBoolean();

		//return Verify.getBoolean();
		//return getBoolean2(true);
	}
/*	public static boolean getBoolean2(boolean x) {
		return x;
	}*/

}
