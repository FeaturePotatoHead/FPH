This is a dummy feature.
It is activated if either MSTPrim or MSTKruskal are active.
I need it to define scenarios in which MinimalSpanningTrees are computed by one of the algorithms (i cannot use "or" in the scenario constraints).

