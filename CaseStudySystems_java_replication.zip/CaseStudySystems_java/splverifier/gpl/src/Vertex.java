
import java.util.LinkedList; 
import java.lang.Integer; 
import java.util.Collections; 
import java.util.Comparator; 
// ***********************************************************************
   
public    class  Vertex {
	
    public LinkedList adjacentVertices;

	
    public String name;

	
   
    public Vertex() {
        VertexConstructor();
    }

	

    public void  VertexConstructor__before__Weighted() {
        name      = null;
        adjacentVertices = new LinkedList();
    }

	

    public void  VertexConstructor__role__Weighted() {
        VertexConstructor__before__Weighted();
        weightsList = new LinkedList();
    }

	
 
    public void 
VertexConstructor__before__Search() {
    if (verificationClasses.FeatureSwitches.__SELECTED_FEATURE_Weighted) {
        VertexConstructor__role__Weighted();
    } else {
        VertexConstructor__before__Weighted();
    }
}



	
 
    public void  VertexConstructor__role__Search() {
        VertexConstructor__before__Search();
        visited = false;
    }

	
 
    public void
VertexConstructor() {
    if (verificationClasses.FeatureSwitches.__SELECTED_FEATURE_Search) {
        VertexConstructor__role__Search();
    } else {
        VertexConstructor__before__Search();
    }
}



	

    public  Vertex assignName( String name ) {
        this.name = name;
        return ( Vertex ) this;
    }

	
   
    public void addAdjacent( Vertex n ) {
        adjacentVertices.add( n );
    }

	

    public void  adjustAdorns__before__Weighted( Vertex the_vertex, int index )
      {}

	

    public void  adjustAdorns__role__Weighted( Vertex the_vertex, int index )
    {
        int the_weight = ( ( Integer )the_vertex.weightsList.get( index ) ).intValue();
        weightsList.add( new Integer( the_weight ) );
        adjustAdorns__before__Weighted( the_vertex, index );
    }

	
    
    public void
adjustAdorns( Vertex the_vertex, int index ) {
    if (verificationClasses.FeatureSwitches.__SELECTED_FEATURE_Weighted) {
        adjustAdorns__role__Weighted(the_vertex, index);
    } else {
        adjustAdorns__before__Weighted(the_vertex, index);
    }
}



	
      
    public void  display__before__Weighted() {
        int s = adjacentVertices.size();
        int i;

        Main.print( "Vertex " + name + " connected to: " );
        for ( i=0; i<s; i++ )
            Main.print( ( ( Vertex ) adjacentVertices.get( i ) ).name 
                                                + ", " );
        Main.println();
    }

	
      
    public void  display__role__Weighted()
    {
        int s = weightsList.size();
        int i;

        Main.print( " Weights : " );

        for ( i=0; i<s; i++ ) {
            Main.print( ( ( Integer )weightsList.get( i ) ).intValue() + ", " );
        }

        display__before__Weighted();
    }

	
                          
    public void 
display__before__Search() {
    if (verificationClasses.FeatureSwitches.__SELECTED_FEATURE_Weighted) {
        display__role__Weighted();
    } else {
        display__before__Weighted();
    }
}



	
                          
    public void  display__role__Search() {
        if ( visited )
            Main.print( "  visited " );
        else
            Main.println( " !visited " );
        display__before__Search();
    }

	
   
    public void 
display__before__Shortest() {
    if (verificationClasses.FeatureSwitches.__SELECTED_FEATURE_Search) {
        display__role__Search();
    } else {
        display__before__Search();
    }
}



	
   
    public void  display__role__Shortest() {
        Main.print( " Pred " + predecessor +" DWeight " + dweight + " " );
        display__before__Shortest();
    }

	 // weight so far from s to it
      
    public void 
display__before__MSTKruskal() {
    if (verificationClasses.FeatureSwitches.__SELECTED_FEATURE_Shortest) {
        display__role__Shortest();
    } else {
        display__before__Shortest();
    }
}



	 // weight so far from s to it
      
    public void  display__role__MSTKruskal() {
        if ( representative==null )
            Main.print( "Rep null " );
        else
            Main.print( " Rep " + representative.name + " " );
        display__before__MSTKruskal();
    }

	
      
    public void 
display__before__MSTPrim() {
    if (verificationClasses.FeatureSwitches.__SELECTED_FEATURE_MSTKruskal) {
        display__role__MSTKruskal();
    } else {
        display__before__MSTKruskal();
    }
}



	
      
    public void  display__role__MSTPrim() {
        Main.print( " Pred " + pred + " Key " + key + " " );
        display__before__MSTPrim();
    }

	 // weight so far from s to it
      
    public void 
display__before__Cycle() {
    if (verificationClasses.FeatureSwitches.__SELECTED_FEATURE_MSTPrim) {
        display__role__MSTPrim();
    } else {
        display__before__MSTPrim();
    }
}



	 // weight so far from s to it
      
    public void  display__role__Cycle() {
        Main.print( " VertexCycle# " + VertexCycle + " " );
        display__before__Cycle();
    }

	 // white ->0, gray ->1, black->2
      
    public void 
display__before__StronglyConnected() {
    if (verificationClasses.FeatureSwitches.__SELECTED_FEATURE_Cycle) {
        display__role__Cycle();
    } else {
        display__before__Cycle();
    }
}



	 // white ->0, gray ->1, black->2
      
    public void  display__role__StronglyConnected() {
        Main.print( " FinishTime -> " + finishTime + " SCCNo -> " 
                        + strongComponentNumber );
        display__before__StronglyConnected();
    }

	
      
    public void 
display__before__Connected() {
    if (verificationClasses.FeatureSwitches.__SELECTED_FEATURE_StronglyConnected) {
        display__role__StronglyConnected();
    } else {
        display__before__StronglyConnected();
    }
}



	
      
    public void  display__role__Connected() {
        Main.print( " comp# "+ componentNumber + " " );
        display__before__Connected();
    }

	

    public void 
display__before__Number() {
    if (verificationClasses.FeatureSwitches.__SELECTED_FEATURE_Connected) {
        display__role__Connected();
    } else {
        display__before__Connected();
    }
}



	

    public void  display__role__Number() {
        Main.print( " # "+ VertexNumber + " " );
        display__before__Number();
    }

	

    public void
display() {
    if (verificationClasses.FeatureSwitches.__SELECTED_FEATURE_Number) {
        display__role__Number();
    } else {
        display__before__Number();
    }
}



	
    public LinkedList weightsList;

	
         
    public void addWeight( int weight )
    {
        weightsList.add( new Integer( weight ) );
    }

	
    public boolean visited;

	
    
    public void init_vertex( WorkSpace w ) {
        visited = false;
        w.init_vertex( ( Vertex ) this );
    }

	
    public void dftNodeSearch( WorkSpace w ) {
        int           s, c;
        Vertex v;

        // Step 1: Do preVisitAction. 
        //                        If we've already visited this node return

        w.preVisitAction( ( Vertex ) this );
         
        if ( visited )
            return;

        // Step 2: else remember that we've visited and 
        //         visit all adjacentVertices

        visited = true;
         
        s = adjacentVertices.size();
        for ( c = 0; c < s; c++ ) 
                {
            v = ( Vertex ) adjacentVertices.get( c );
            w.checkNeighborAction( ( Vertex ) this, v );
            v.dftNodeSearch( w );
        }
        ;
     
        // Step 3: do postVisitAction now
        w.postVisitAction( ( Vertex ) this );
    }

	
    public void bftNodeSearch( WorkSpace w ) {
        int           s, c;
        Vertex  v;
        Vertex  header;

        // Step 1: if preVisitAction is true or if we've already
        //         visited this node

        w.preVisitAction( ( Vertex ) this );
                
        if ( visited )
            return;

        // Step 2: Mark as visited, put the unvisited adjacentVertices in the queue 
        //         and make the recursive call on the first element of the queue
        //         if there is such if not you are done

        visited = true;
         
        // Step 3: do postVisitAction now, you are no longer going through the
        // node again, mark it as black
        w.postVisitAction( ( Vertex ) this );
        
        s = adjacentVertices.size();
        
        // enqueues the vertices not visited
        for ( c = 0; c < s; c++ ) 
                {
            v = ( Vertex ) adjacentVertices.get( c );

            // if your neighbor has not been visited then enqueue 
            if ( !v.visited )
                                    {
                GlobalVarsWrapper.Queue.add( v );
            }
                                        
        } // end of for
         
        // while there is something in the queue
        while( GlobalVarsWrapper.Queue.size()!=0 )
                {
            header = ( Vertex ) GlobalVarsWrapper.Queue.get( 0 );
            GlobalVarsWrapper.Queue.remove( 0 );
            header.bftNodeSearch( w );
        }
    }

	
    public String predecessor;

	 // the name of the predecessor if any
    public int dweight;

	
    public  Vertex representative;

	
    public LinkedList members;

	
    public String pred;

	 // the name of the predecessor if any
    public int key;

	
    public int VertexCycle;

	
    public int VertexColor;

	
    public int finishTime;

	
    public int strongComponentNumber;

	
    public int componentNumber;

	
    public int VertexNumber;


}
